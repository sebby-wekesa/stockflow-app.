# Fix: production orders now flow through every operation (not straight to dispatch)

## The bug

When a new production order was created, completing the first step sent it
straight to dispatch instead of advancing through the FML/RML operations.

**Root cause — two completion systems collided:**

- The **new** Operations flow (`actions/operations.ts`) is correct: it only
  finishes an order when *every* operation is done.
- The **old** design-stage flow (`app/actions/stage-completion.ts`) finds the
  next step from `order.design.stages`. A direct/routed order has **no design**,
  so "next stage" was `undefined`, the code assumed it was the *final* stage, and
  marked the order `COMPLETED` after the very first completion → dispatch.

On top of that, the create flow never set the order's `routeType` and never
created the operation steps — so the operations the order should walk through
didn't exist.

## The fix

1. **New orders now carry a route and auto-create their operations.**
   `createDirectProductionOrder` takes a `routeType` (FML/RML). On creation it
   stores the route and immediately materialises every operation step from the
   matching `ProductionRoute` — no separate "start routing" button. Production
   just ticks each step Start → Done, and the order only reaches completion /
   dispatch when the **last** operation is done.

2. **The old design-stage path is now blocked for routed/direct orders.**
   `completeStage` refuses any order that has a `routeType`, or that has no
   design, telling the user to use the operations tracker. This removes the
   collision permanently.

3. **The Quick order form now has a route selector.** Admin picks
   None / FML / RML. For FML, three eye-rolling checkboxes (Eye Rolling /
   Scaffolding / Tapering) let them pre-select which optional steps this order
   uses; unticked ones are recorded as skipped (still changeable while tracking).

4. **Shared logic extracted to `lib/operation-routing.ts`** so both the create
   flow and the manual "start routing" action use one code path.

## Files changed

| File | Change |
|---|---|
| `lib/operation-routing.ts` | **New.** `materializeOperationsForOrder` — creates the OperationLog rows for an order from its route. |
| `actions/operations.ts` | `startOrderRouting` now delegates to the shared helper. |
| `actions/production-order.ts` | `createDirectProductionOrder` accepts `routeType` + optional eye-rolling steps; sets the route and auto-creates operations on creation. |
| `app/actions/stage-completion.ts` | Guards the legacy stage flow against routed/direct orders (the actual bug fix). |
| `components/DirectOrderForm.tsx` | Route selector + eye-rolling step checkboxes. |

## Deploy

No new migration — these are logic/UI changes on top of the
`20260606000000_production_routing` migration you already have. Just rebuild:

```bash
cd stockflow
npx prisma generate   # if not already done for the routing migration
npm run build
```

## To use it

1. Open `/operations` once and click **"Set up / refresh FML & RML routes"** (if
   you haven't already) so the two routes exist.
2. Create a production order on the **Quick order** tab and pick **FML** or
   **RML** (and, for FML, tick which eye-rolling steps apply).
3. The order appears in `/operations` with all its steps. Open it and tick each
   one Start → Done. It only moves to completion/dispatch after the **last**
   operation is done.

## Note on the empty upload

The `stockflow-app_zipped.zip` you attached this turn was 182 bytes and contained
only an empty folder — no source files — so these changes were made on the
June 6 copy. Re-zip with the full `stockflow` project inside (the working upload
was ~2.8 MB) if you want me to work from your very latest code; nothing here
depends on it, though.
