# Direct Production Orders — what changed

This removes the requirement to create a Design template before every production
order. The admin can now create an order directly by stating the product name,
the material(s) to cut, and the expected finished-piece count.

## The new flow

**Admin (Quick order tab on `/place_order`):**
- Product name (free text) — e.g. "Hilux rear spring leaf"
- Expected finished pieces — e.g. 15  (this is the predicted output)
- One or more material lines, each: material (picked from your saved list),
  cut length (cm), pieces, total length (auto-fills as cut × pieces, editable)
- Priority + optional notes

**Production side (action ready, UI is the next step — see below):**
- Records actual weight out and actual finished pieces
- System computes efficiency = actual pieces ÷ expected pieces (e.g. 14/15 = 93.3%)

The old Design-template flow still works — it's now the "From saved template" tab.

## Files changed

| File | Change |
|---|---|
| `prisma/schema.prisma` | `ProductionOrder.designId` and `targetKg` are now optional. Added `productName`, `expectedPieces`, `actualPieces`, `actualKgOut`, `notes`. New `ProductionOrderMaterial` child table (one order can carry several materials). |
| `prisma/migrations/20260605000000_direct_production_orders/` | The migration SQL for the above. |
| `actions/production-order.ts` | New `createDirectProductionOrder`, `recordProductionOutput` (computes efficiency), and `saveOrderAsTemplate`. Existing design-based create untouched. |
| `actions/raw-materials.ts` | New `listRawMaterialsForPicker` — feeds the material dropdown with labels like "80x13 flat bar". |
| `app/actions/orders.ts` | Approval now branches: design-based orders consume per BOM as before; direct orders approve and move to production without a fixed BOM. |
| `components/DirectOrderForm.tsx` | The new admin form (multi-material, auto-total). |
| `app/(dashboard)/place_order/page.tsx` | Two tabs: **Quick order** (default, the new direct form) and **From saved template** (the old design flow). |

## Deploy steps

```bash
# 1. Apply the migration to your database
cd stockflow
npx prisma migrate deploy        # applies 20260605000000_direct_production_orders

# 2. Regenerate the Prisma client for the new fields/table
npx prisma generate

# 3. Build & run
npm run build
```

Note: the migration is additive and safe — it only relaxes two NOT NULL
constraints and adds new columns/a new table. No existing data is changed, and
existing design-based orders keep working exactly as before.

## The one piece still to wire: the production-side input

`recordProductionOutput(orderId, actualPieces, actualKgOut?)` is written, typed,
and returns the efficiency. What's left is a small UI on the production/operator
screen (`/operator_log` or `/stage-logger`) with two fields — actual pieces and
actual weight out — that calls it and shows the efficiency result.

I held off building that screen because I didn't want to guess at the operator
page's structure and risk breaking your existing stage-logging. Point me at how
you want production staff to enter this (a field on the existing stage log, or a
dedicated "record output" button on the order), and I'll wire it in.

## Two design choices worth confirming

1. **Direct orders don't reserve raw stock at approval.** Because the material
   is weighed on the floor (your words), a direct order currently approves
   without decrementing `availableKg`. If you'd rather hold stock at approval
   based on the material lines, that's a small addition — say the word.

2. **Save-as-template** stores the material lines + expected pieces in the
   Design's `specifications` JSON. When you later build "create order from this
   template", it reads that JSON back. The template path is ready to save into;
   reading it back into a prefilled Quick order form is a small follow-up.
