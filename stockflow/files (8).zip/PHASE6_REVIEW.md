# Phase 6 — Deferred cleanup, branches UI, approval emails

**Status: ready for deploy. Three pieces of long-overdue work.**

## What changed

### 1. Removed unsafe auto-create from `signIn`

The old code did this in `actions/auth.ts`:

- If a Supabase auth user logs in but has no Prisma `User` row → create one with `role: 'PENDING'`, no organizationId
- If they have a User row but no organization → find any organization that exists and attach the user to it

The first path would crash because `organizationId` is NOT NULL in the schema (the catch block swallowed it silently — so logins appeared to succeed but subsequent requests failed). The second path was the real danger: **a brand-new user could be auto-attached to Springtech and see Springtech's data**.

I replaced both branches with a clean rejection: if you sign in without a fully-set-up Prisma User row tied to an organization, you get signed out and told to complete signup or contact your admin. The two legitimate paths to creating a User row are still in place:

- `signUpOrganization` for new org owners
- `inviteUser` for teammates of an existing org

If those didn't happen, the account is incomplete — surface that clearly rather than paper over it.

### 2. New `/settings/branches` page

`actions/branches.ts` + `app/(dashboard)/settings/branches/page.tsx` + `BranchesClient.tsx`. Admins and managers can:

- Create branches with name, code, optional location/address/phone
- Edit existing branches
- See per-branch counts (users · products · stock movements)
- Delete branches — but only if they have zero dependent records (otherwise the action returns a friendly error listing what's blocking)

Codes are normalized to lowercase. Branch names and codes are unique per organization (Postgres enforces this via the existing `@@unique` constraints; the action also pre-checks for a friendlier error than P2002).

This unblocks the onboarding flow — the "Add a branch" button on `/onboarding` no longer 404s.

### 3. Approval email automation

`lib/email.ts` defines a small `sendEmail()` abstraction with two backends:

- **Resend** when `RESEND_API_KEY` is set — production
- **Console log** when it isn't — development/fallback

The Resend backend uses plain `fetch` against their REST API, so there's no new npm dependency. To activate:

```bash
# In your env (after signing up at resend.com and verifying a sending domain)
RESEND_API_KEY=re_...
EMAIL_FROM=StockFlow <noreply@notifications.fortunepath.co.ke>
```

Without these, the code falls back to logging would-be emails to the server console, so the rest of the flow works without a Resend account.

`lib/emails/org-status.ts` contains four plain-text templates:
- Approved — "your org is live, sign in here"
- Rejected — "we couldn't approve you, here's why"
- Suspended — "your org has been suspended, here's why"
- Reactivated — "you're back, sign in again"

`actions/admin-orgs.ts` now sends the appropriate email after each status transition. **Email failures don't roll back the status change** — the DB has already committed by then; we log the failure and move on. The customer will see they're approved next login anyway.

### 4. Bonus bug fix: OrgActions FormData mismatch

While I was in `app/admin/orgs/_components/OrgActions.tsx`, I noticed the client was sending FormData to `suspendOrganization(orgId, reason)` and `rejectOrganization(orgId, reason)` — but the actions take a plain string (signature changed in Phase 1, client wasn't updated). The actions were receiving `"[object FormData]"` as the reason. Suspend/reject would have worked but stored a literal string `"[object FormData]"` as the disabledReason — broken since Phase 1 shipped.

Fixed by passing the plain `reason` string instead of constructing FormData.

## Files

| File | Status | What |
|---|---|---|
| `actions/auth.ts` | modified | Removed dangerous auto-create-and-attach; now rejects incomplete accounts cleanly |
| `actions/admin-orgs.ts` | modified | Sends notification emails after each status change |
| `actions/branches.ts` | new | createBranch / updateBranch / deleteBranch with safety checks |
| `lib/email.ts` | new | Resend-backed email send with console fallback |
| `lib/emails/org-status.ts` | new | Four plain-text email templates |
| `app/(dashboard)/settings/branches/page.tsx` | new | Branch list + dependency counts |
| `app/(dashboard)/settings/branches/_components/BranchesClient.tsx` | new | Modal-based CRUD UI |
| `app/admin/orgs/_components/OrgActions.tsx` | modified | Fix FormData/string mismatch |

## What we DIDN'T need to change

The original Phase 6 plan said "audit ~15 files still using raw `prisma.*`". When I ran the actual inventory, only 4 files imported raw prisma, and **3 of them were correct**:

- `actions/admin-orgs.ts` — super-admin cross-org operations, correctly use raw prisma
- `actions/signup.ts` — bootstrap before any org exists, no orgId available yet
- `app/actions/customer-portal.ts` — customer login bootstrap; correctly switches to `getTenantPrisma` after auth

Only `actions/auth.ts` had genuinely unsafe raw-prisma usage, which I fixed above. The other ~15 files were converted to tenant-scoping in earlier work. So Phase 6 is leaner than expected — the dirty work was already done.

## Deploy

```bash
cd stockflow
unzip -o phase6-cleanup.zip
npm run build
```

No migrations required. After deploy, you get:

1. **Safer sign-in.** Users without a fully-set-up account are sent away with a clear message instead of being silently dropped into someone else's org.
2. **Working onboarding.** New tenants can complete the three-step setup without hitting a 404.
3. **Status emails.** As soon as you set up Resend (or even without — the console will log them in dev), org owners get notified when you approve, suspend, reactivate, or reject them.

## To activate Resend

1. Sign up at https://resend.com (free tier: 3k emails/month, plenty for org-status notifications)
2. Add and verify a sending domain you control (e.g. `notifications.fortunepath.co.ke`) — Resend will give you DNS records to add
3. Create an API key
4. Set `RESEND_API_KEY=re_...` and `EMAIL_FROM=StockFlow <noreply@yourdomain>` in env
5. Redeploy

Without these env vars, emails go to the server console (no crash, just logged). You can ship Phase 6 today and add Resend later.

## What's still on the list

- **`/settings/organization`** — view + edit org-level details (name, address, phone). Optional but nice to have.
- **The unused-import warning** I'd flag in `actions/auth.ts` — `getTenantPrisma` and `ALL_BRANCHES` are now gone, but if you have an eslint pass it might flag other things. Not blocking.
- **Phase 7 — Cashia billing integration.** Your original plan.

## Caveats

1. **Resend's free tier uses `onboarding@resend.dev` as the from-address** if you don't verify a domain. That gets through most spam filters during testing but you'll want a verified domain for production. Set `EMAIL_FROM` accordingly.

2. **Email send blocks the action.** I considered fire-and-forget but on Vercel/Lambda the serverless function can be killed once the response is returned, killing the in-flight fetch with it. Awaiting the send (with a 5-second timeout) guarantees the email leaves before the function recycles. Cost: each approve/suspend takes 200-500ms longer. Acceptable for an admin-facing action.

3. **The `User` row check in `signIn` doesn't reach the User table via Supabase auth.users**. It only checks our Prisma User table. If you ever have a Supabase auth user that's been deleted from Prisma manually (rare), they'll be politely told to contact support — which is correct.

4. **Branch delete only allows ADMIN.** Managers can create/edit but not delete. Deleting a branch with history would orphan stock movements, so this is intentional.

5. **CSP from Phase 5 will need `connect-src` to include Resend's API** (`https://api.resend.com`) if the email sending happens from a route that's affected by CSP. In practice, server-side `fetch` from Server Actions isn't subject to browser CSP — the browser CSP only affects what the browser does. So no CSP change needed.

## Recommendation

Deploy Phase 6. Sign up for Resend and set the env vars when convenient — Phase 6 works without Resend, just degrades emails to console logs.

After Phase 6 you have the full multitenant app: signup flow, approval workflow with email notifications, complete onboarding (branches → import → invite team), and the safe sign-in path. New tenants can self-serve from `/signup` end-to-end.

Say "continue" for Phase 7 (Cashia billing integration), or stop here if you'd rather sit on Phases 1-6 and watch them bed in.
