# Phase 5 — Production security hardening

**Status: ready for deploy. Three big improvements: nonce-based CSP, global security headers, Upstash-backed rate limiting.**

This phase replaces the temporary security stopgaps with production-grade implementations. After Phase 5 you should be comfortable making `/signup` publicly discoverable.

## What changed

| File | What | Why |
|---|---|---|
| `middleware.ts` | Generates a per-request CSP nonce and attaches `Content-Security-Policy` to every response. Forwards `x-nonce` into the request so Next.js stamps it onto inline scripts. Now also runs on `/api/*` routes (it used to skip them). | The old CSP had `'unsafe-inline'` and `'unsafe-eval'` — both defeat most of CSP's XSS protection. Nonces let inline scripts run only if they carry a fresh, unguessable token. |
| `next.config.ts` | Added `headers()` to apply X-Content-Type-Options, X-Frame-Options, X-XSS-Protection, Referrer-Policy, Permissions-Policy, and (in production) Strict-Transport-Security to every response. | Previously these were attached only to specific API routes. Now every page response gets them. |
| `lib/security.ts` | `getSecurityHeaders()` now omits CSP (deprecated; CSP comes from middleware). Other headers still returned for backward-compat with one existing API-route caller. | If both the route AND middleware set CSP, the last-write-wins shadows the nonce-based one. |
| `lib/rate-limit.ts` | New Upstash Redis backend selected automatically when `UPSTASH_REDIS_REST_URL` is set; in-memory fallback otherwise. New `checkRateLimitAsync(key, opts)` is the preferred entry point. | The in-memory limiter leaks across serverless instances. Upstash gives a globally-consistent counter. |
| `actions/auth.ts` | `signIn` now uses `checkRateLimitAsync` and `await`s it. | Routes Phase 1's rate limit through Upstash when available. |
| `actions/signup.ts` | Same for `signUpOrganization`. | Same reason. |

## How the CSP actually works now

Old CSP (from `lib/security.ts`):

```
script-src 'self' 'unsafe-inline' 'unsafe-eval'
style-src  'self' 'unsafe-inline'
```

`'unsafe-inline'` means injected `<script>...</script>` runs. `'unsafe-eval'` means `eval(maliciousString)` runs. Combined, they make CSP almost cosmetic.

New CSP (in `middleware.ts`):

```
script-src 'self' 'nonce-AbC123...' 'strict-dynamic'
style-src  'self' 'nonce-AbC123...'
```

Each request gets a unique nonce. Next.js stamps it onto its own `<script>` tags via the `x-nonce` request header. `'strict-dynamic'` lets nonce'd scripts dynamically load other scripts (necessary for Next.js's chunk loader) without the dynamic ones needing their own nonces.

For an attacker to inject a script via XSS, they'd need to guess a random nonce that changes every request. That's the whole point.

**Caveat**: in `development` we still allow `'unsafe-eval'` because React uses `eval()` to reconstruct stack traces. Production builds don't use eval — neither React nor Next.js does — so production CSP is fully strict.

## Why we use `Content-Security-Policy-Report-Only` first (recommended)

CSP is one of those features where the consequences of getting a directive slightly wrong are "the whole app is white-screen blank" — and you only notice in production. There's a safer rollout:

1. Set `CSP_REPORT_ONLY=1` in your env on first deploy
2. Browsers will log CSP violations to the console but not block anything
3. Open the dashboard, the inventory page, the import flow — anywhere users go
4. Check the browser console. Each violation tells you what was blocked
5. Adjust the policy (or fix the code) to address legitimate violations
6. Remove the env var → CSP enforces

I've built that env-driven toggle into the middleware. **I strongly recommend deploying with `CSP_REPORT_ONLY=1` on the first push, then flipping it off after a day of monitoring.**

## Permissions-Policy

The list of disabled APIs is conservative — camera, microphone, geolocation, payment, USB, magnetometer, gyroscope. Extend as needed (e.g. `interest-cohort=()` if you're concerned about FLoC). The app doesn't use any of these, so disabling them is free defence-in-depth.

## HSTS — production only

`Strict-Transport-Security: max-age=63072000; includeSubDomains; preload` tells the browser "for the next 2 years, refuse to load this domain over plain HTTP, no matter what." This is irreversible for that browser-host pair — once set, the user can't accept a self-signed cert or downgrade. We only emit it in production for that reason.

The `preload` token makes you eligible for the browser-baked-in HSTS preload list. To actually get there, submit your domain at https://hstspreload.org/ — that's a manual step you can do later.

## Upstash rate limiting

The current in-memory limiter doesn't work across serverless instances. Each Lambda has its own Map; an attacker who hits parallel cold instances bypasses the limit entirely.

The new code switches to Upstash Redis automatically when you set:

```bash
UPSTASH_REDIS_REST_URL=https://us1-...upstash.io
UPSTASH_REDIS_REST_TOKEN=...
```

It uses a fixed-window counter via INCR+EXPIRE. The REST API works from any Next.js runtime (Node, Edge, Lambda). Set both env vars to enable; leave them unset and the in-memory fallback is used (fine for local dev).

**Fail-open semantics**: if Upstash is unreachable (network blip, Upstash down), we log the error and let the request through rather than locking everyone out. The 2-second timeout means a worst-case 2-second wait, not a hung request.

To set up Upstash:
1. Sign up at https://upstash.com — free tier is 10k commands/day, plenty for auth
2. Create a Redis database, pick a region near your Vercel/Render deployment
3. Copy the REST URL + REST Token
4. Set the env vars
5. Redeploy

No code change needed when you switch on Upstash. The library auto-detects.

## Deploy

```bash
cd stockflow
unzip -o phase5-security-hardening.zip
npm run build       # should stay green
```

**Recommended deploy sequence** (please follow):

1. **First push**: set `CSP_REPORT_ONLY=1` in your env. Deploy. Click through every major page (dashboard, inventory, import, sales, signup flow). Open browser DevTools and watch the console for `Content Security Policy` warnings.
2. **If you see violations**: tell me what they say, I'll adjust the policy. Or fix the offending code (most violations indicate something that should be moved out of inline anyway).
3. **Once clean**: remove `CSP_REPORT_ONLY` from env. Redeploy. CSP now enforces.
4. **Upstash**: once you have an Upstash account, set the two env vars. Redeploy. Rate limits become globally-consistent across all serverless instances.

## What this does NOT fix

Still on the list:
- **Phase 6** — the deferred Stage 3b cleanup (~15 files still using raw `prisma.*`), `/settings/branches` UI (onboarding 404s here), automated approval email
- **Cashia billing integration** — your original plan, deferred until 6 is done

## Caveats and decisions worth flagging

1. **Middleware now runs on `/api/*` too.** Previously it skipped API routes entirely. Now it attaches CSP and forwards the nonce. The auth/role-checking branches still early-return for `/api/*` — only the security-header injection runs. Net effect: API responses get security headers, no functional change to the auth/routing logic.

2. **`getSecurityHeaders()` is deprecated.** One API route (`app/api/production-orders/route.ts`) still calls it; I left the helper functional minus the CSP entry so that route keeps working. Phase 6 should remove the call entirely — the global headers cover it.

3. **HSTS `preload` is included.** Once you go production and a browser caches HSTS for your domain, that browser will refuse HTTP for 2 years. If you have any HTTP-only subdomain that needs to be reachable, **drop `includeSubDomains`** from the HSTS value before deploying. The `preload` token alone doesn't enroll you in the browser-baked-in list — that's a separate submission at https://hstspreload.org/.

4. **`'strict-dynamic'`** in script-src means: scripts loaded with a valid nonce can load other scripts without nonces. This is required for Next.js to load its chunks. It does mean any third-party script you load (e.g. analytics) inherits the trust of the script that loaded it — so be careful what your nonce'd code loads.

5. **The Upstash fail-open behaviour** is a deliberate trade-off. Failing closed (deny everything when Redis is down) protects against bypasses but lets a Redis outage take down your auth. Failing open lets a Redis outage degrade gracefully to "no rate limit" — bad but recoverable. Most production rate limiters choose fail-open. Change `checkAndIncrementUpstash` if you'd rather fail-closed.

6. **CSP `connect-src` allows your Supabase project.** I used wildcards (`https://*.supabase.co wss://*.supabase.co`) so it works for any Supabase project. If you want to lock this down to your specific Supabase URL, replace the wildcards with your actual hostname.

## Recommendation

Deploy in report-only mode on the next push. Watch the console for an hour or two. Then flip to enforce. The rest of the changes (next.config.ts headers, deprecation tidy, Upstash integration) need no rollout — they apply immediately and are backward-compatible.

Say "continue" for Phase 6 (the deferred cleanup work and `/settings/branches`).
